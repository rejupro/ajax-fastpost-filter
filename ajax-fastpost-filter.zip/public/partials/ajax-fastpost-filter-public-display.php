<?php

/**
 * Provide a public-facing view for the plugin
 *
 * This file is used to markup the public-facing aspects of the plugin.
 *
 * @link       https://https://facebook.com/rejutpi
 * @since      1.0.0
 *
 * @package    Ajax_Fastpost_Filter
 * @subpackage Ajax_Fastpost_Filter/public/partials
 */
?>

<!-- This file should primarily consist of HTML with a little bit of PHP. -->
